const express = require('express');
const router = express.Router();
const controller = require('../controllers/controller')

router.get('/', controller.shoes);
router.get('/women', controller.women);
router.get('/men', controller.men);
router.get('/accessories', controller.accessories);
router.get('/cart', controller.cart);

module.exports = router;