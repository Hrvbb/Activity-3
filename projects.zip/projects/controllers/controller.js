const controller = {
    shoes: (req, res) => {
        res.render('shoes', {title: 'Shoes'});
    },

    women: (req, res) =>{
        res.render('women', {title: 'Womens Apparel'});
    },

    men: (req, res) => {
        res.render('men', {title: 'Mens Apparel'});
    },

    accessories: (req, res) => {
        res.render('accessories', {title: 'Accessories'});
    },

    cart: (req, res) => {
        res.render('cart', {title: 'My Cart'});
    }
};

module.exports = controller;